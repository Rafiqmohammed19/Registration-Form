# registration-form

1. clone the repo.
   using :- git clone link

2. To install the modules:
   run :- npm install

3. To start the server:
   run :- node index.js
